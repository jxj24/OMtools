%pp.m: Phase Plane axis labels
ylabel( 'Eye Velocity (�/sec)' )
xlabel( 'Eye Position (�)' )