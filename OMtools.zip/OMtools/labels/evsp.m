%epsp.m: Eye Velocity Scan Path axis labels
ylabel( 'Vertical Eye Velocity (�/sec)' )
xlabel( 'Horizontal Eye Velocity (�/sec)' )