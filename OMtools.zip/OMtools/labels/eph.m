%eph.m: Eye Position Histogram axis labels
ylabel( 'Number of Data Points' )
xlabel( 'Eye Position (�)' )